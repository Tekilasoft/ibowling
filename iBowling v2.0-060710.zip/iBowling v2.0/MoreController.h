#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface MoreController : UIViewController /* Specify a superclass (eg: NSObject or NSView) */ {

}

@end
