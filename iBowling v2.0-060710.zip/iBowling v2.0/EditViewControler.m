#import "EditViewControler.h"
#import "Game.h"
#import "AppDelegate.h"

@implementation EditViewControler

@synthesize part1, part2, part3, part4, date, game, add, set,lp,lm, office, value, description;
@synthesize lab1, lab2,lab3,lab4,labg, labo, l4;
@synthesize doneButton;


- (void)viewDidLoad {
    self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonSystemItemCancel 
																			 target:self action:@selector(cancel:)] autorelease];
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonSystemItemSave 
																			  target:self action:@selector(save:)] autorelease];
	showTab=FALSE;
}

- (void)keyboardWillShow:(NSNotification *)note{
	
	//if (description.tag!=4){
		NSLog(@"TAAGSSS= %d",description.tag);
	//if (doneButton==nil){
		/*doneButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 163, 106, 53)];
		//[doneButton setFrame:CGRectMake(0, 100, 106, 53)];
		doneButton.adjustsImageWhenHighlighted = NO;
		[doneButton setTitle:@" Tab" forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"tab.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"tab.png"] forState:UIControlStateHighlighted];
		[doneButton addTarget:self action:@selector(tabButton:) forControlEvents:UIControlEventTouchUpInside];
		*/
		UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1];
		UIView* keyboard;
		for(int i=0; i<[tempWindow.subviews count]; i++) {
			//NSLog(@"TAAG %d = %d",i,showTab);
			keyboard = [tempWindow.subviews objectAtIndex:i];
			// keyboard view found; add the custom button to it
			//if([[keyboard description] hasPrefix:@"<UIKeyboard"] == YES){
				NSLog(@"TAAG %d = %d",i,showTab);
				[keyboard addSubview:doneButton];
			//if ([description )
				doneButton.hidden=TRUE;
				//if (description.tag!=4 )
				//if (office.tag!=4)
				if (showTab)
					doneButton.hidden=FALSE;
			//}
		}
	//}
	//description.tag=0;
}
- (void)keyboardWillHide:(NSNotification *)note{
	doneButton.hidden=TRUE;
}
- (IBAction)textPave{
	description.tag=4;
	office.tag=4;
	date.hidden=TRUE;
	NSLog(@"tag haja =%d",office.tag);
	doneButton.hidden=TRUE;
}

- (void)dealloc {
    // Release allocated resources.
	NSLog(@"Quitter");
	[doneButton release];
    [game release];
	[part4 release];
	[part3 release];
	[part2 release];
	[part1 release];
	[add release];
	[set release];
	[date release]; 
    [lp release];
	[lm release];
	[office release];
	[lab1 release]; 
	[lab2 release]; 
	[lab3 release]; 
	[lab4 release]; 
	[labg release]; 
	[labo release]; 
    [value release];
	[description release];
    [super dealloc];
}
/*
- (void)viewWillDisappear {
	NSLog(@" - Remove NSNotificationCenter on viewDidUnload because I create him in the viewDidLoad");
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)viewDidDisappear {
	NSLog(@"Remove NSNotificationCenter on viewDidUnload because I create him in the viewDidLoad");
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}
 */
- (void)viewWillAppear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWillShow:) 
												 name:UIKeyboardDidShowNotification object:nil];
	//NSLog(@"id Nature = %i", idNature);
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	//doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
	doneButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 163, 106, 53)];
	//[doneButton setFrame:CGRectMake(0, 100, 106, 53)];
	doneButton.adjustsImageWhenHighlighted = NO;
	[doneButton setTitle:@" Tab" forState:UIControlStateNormal];
	[doneButton setImage:[UIImage imageNamed:@"tab.png"] forState:UIControlStateNormal];
	[doneButton setImage:[UIImage imageNamed:@"tab.png"] forState:UIControlStateHighlighted];
	[doneButton addTarget:self action:@selector(tabButton:) forControlEvents:UIControlEventTouchUpInside];
	lp.hidden=TRUE;
	part4.hidden=TRUE;
	l4.hidden=TRUE;
	add.hidden=FALSE;
	lm.text=@"00.00";
	description.text=@"";
	//description.tag=0;
	office.tag=0;
	
	if(appDelegate.langue==0){//FR
		[self.navigationItem.leftBarButtonItem setTitle:@"Annuler"];
		[self.navigationItem.rightBarButtonItem setTitle:@"Sauvegarder"];
		if(game!=nil)
			self.title = @"Modification";
		else
			self.title = @"Nouvelle série";
		lab1.text=@"ère";
		lab2.text=@"ème";
		lab3.text=@"ème";
		lab4.text=@"ème";
		labg.text=@"Parties";
		labo.text=@"Officielle";
		[add setTitle:@"4ème" forState:UIControlStateNormal];
		[add setTitle:@"4ème" forState:UIControlStateSelected];
		[add setTitle:@"4ème" forState:UIControlStateHighlighted];
	}else {//EN
		[self.navigationItem.leftBarButtonItem setTitle:@"Cancel"];
		[self.navigationItem.rightBarButtonItem setTitle:@"Save"];
		if(game!=nil)
			self.title = @"Update serie";
		else
			self.title = @"New serie";
		lab1.text=@"st";
		lab2.text=@"nd";
		lab3.text=@"rd";
		lab4.text=@"th";
		labg.text=@"Games";
		labo.text=@"Licensed";
		[add setTitle:@"4th" forState:UIControlStateNormal];
		[add setTitle:@"4th" forState:UIControlStateSelected];
		[add setTitle:@"4th" forState:UIControlStateHighlighted];
	}
	if(game!=nil){
		//doneButton.hidden=TRUE;
		part1.text=[NSString stringWithFormat: @"%d",(int) game.p1];
		part2.text=[NSString stringWithFormat: @"%d",(int) game.p2];
		part3.text=[NSString stringWithFormat: @"%d",(int) game.p3];
		isOfficial=game.isOfficial;
		if(((int) game.p4)>0){
			add.hidden=TRUE;
			lp.hidden=FALSE;
			part4.hidden=FALSE;
			l4.hidden=FALSE;
			part4.text=[NSString stringWithFormat: @"%d",(int) game.p4];
		}
		[date setDate:[NSDate dateWithTimeIntervalSince1970:game.jour] animated:TRUE];
		NSDateFormatter *format = [[NSDateFormatter alloc] init];		 
		if (appDelegate.langue==0){//FR
			[format setDateFormat:@"EEEE d-MM-YYYY"];
			[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
			[date setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
			[date setTimeZone:[NSTimeZone timeZoneWithName:@"Fr_FR"]];
		}else{//EN
			[format setDateFormat:@"EEE. MMM d, YYYY"];
			[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
			[date setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
			//[date setTimeZone:[[[NSTimeZone alloc] initWithName:@"US/Pacific"] autorelease]];
			[date setTimeZone:[NSTimeZone timeZoneWithName:@"America/Detroit"]];
			//[date ];
		}
		
		//NSLog(@"Region format :%s",date.timeZone.name);
		[set setTitle:[[format stringFromDate:[NSDate dateWithTimeIntervalSince1970:game.jour]] capitalizedString] forState:UIControlStateNormal];
		[set setTitle:[[format stringFromDate:[NSDate dateWithTimeIntervalSince1970:game.jour]] capitalizedString] forState:UIControlStateSelected];
		[set setTitle:[[format stringFromDate:[NSDate dateWithTimeIntervalSince1970:game.jour]] capitalizedString] forState:UIControlStateHighlighted];
		[format release];
		NSLog(@"Current LOCALE : %@", [[NSLocale currentLocale] localeIdentifier]);
		if(game.description!=nil){
			description.text=game.description;
			NSLog(@"DESRCIPTION : %s",game.description);
			
		}
		lm.text=[NSString stringWithFormat:@"%0.2f",game.moyenne];
		
	}else{//Nouveau jeux
		doneButton.hidden=TRUE;
		part1.text=@"";
		part2.text=@"";
		part3.text=@"";
		part4.text=@"";
		NSDateFormatter *format = [[NSDateFormatter alloc] init];
		NSDate *dt=[[NSDate alloc] init];
		if (appDelegate.langue==0){//FR
			[format setDateFormat:@"EEEE d-MM-YYYY"];
			[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
			[date setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
		}else{//EN
			[format setDateFormat:@"EEE. MMM d, YYYY"];
			[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
			[date setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
		}
		[set setTitle:[[format stringFromDate:dt] capitalizedString] forState:UIControlStateNormal];
		[set setTitle:[[format stringFromDate:dt] capitalizedString] forState:UIControlStateSelected];
		[set setTitle:[[format stringFromDate:dt] capitalizedString] forState:UIControlStateHighlighted];
		
		//[set setState:UIControlStateNormal];
		[format release];
		[date setDate:dt animated:TRUE];
	}
	//[part1 becomeFirstResponder];
	description.tag=4;
	office.tag=4;
	[description becomeFirstResponder];
	[office setOn:isOfficial animated:YES];
	[office setEnabled:TRUE];
	office.hidden=FALSE;
	labo.hidden=FALSE;
	if (idNature==1 || idNature==4){
		[office setEnabled:FALSE];
		office.hidden=TRUE;
		labo.hidden=TRUE;
	}
}

- (IBAction)cancel:(id)sender {
	showTab=FALSE;
	NSLog(@"Miditra CANCEL");
	[self.navigationController popViewControllerAnimated:YES];
	//NSLog(@"Mivoaka Cancel");	
}

- (IBAction)save:(id)sender {
	doneButton.hidden=TRUE;
	showTab=FALSE;
	NSLog(@"Miditra sauvegarde");
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	
	if([part1.text doubleValue]>0 || [part2.text doubleValue]>0 ||[part3.text doubleValue]>0 ){
		
		/*Herison Attente de validation*/
		if([part4.text intValue]>0 && [part3.text intValue]==0){
			part3.text=part4.text;
			part4.text=@"";
		}
		if([part3.text intValue]>0 && [part2.text intValue]==0){
			part2.text=part3.text;
			part3.text=@"";
		}
		if([part2.text intValue]>0 && [part1.text intValue]==0){
			part1.text=part2.text;
			part2.text=@"";
		}
		BOOL fine;
		fine=YES;
		if([part1.text intValue]>300)
			fine=NO;
		if([part2.text intValue]>300)
			fine=NO;
		if([part3.text intValue]>300)
			fine=NO;
		if([part4.text intValue]>300)
			fine=NO;
		if (!fine){
			UIAlertView *alert;
			if (appDelegate.langue==0)
				alert=[[UIAlertView alloc] initWithTitle:@"Erreur iBowling" message:@"Erreur de saisie\n\nLe score doit inférieur ou égale à 300" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
			else
				alert=[[UIAlertView alloc] initWithTitle:@"Error iBowling" message:@"Input error\n\nMaximum value must under 300" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
			[alert show];
			[alert release];
		}else{
			if(game==nil){//Create a new Game if necessary, else, update the game
				game=[[Game alloc] init];
			}
			isOfficial=office.on;
			
			double d=[date.date timeIntervalSince1970];
			[game setValue:d part1:[part1.text doubleValue]  part2:[part2.text doubleValue]  part3:[part3.text doubleValue]  part4:[part4.text doubleValue]  officiel:isOfficial nature:idNature moyenne:[lm.text doubleValue]];
			/*if (isOfficial==TRUE)
				[game setValue:d part1:[part1.text doubleValue]  part2:[part2.text doubleValue] part3:[part3.text doubleValue]  part4:[part4.text doubleValue]  officiel:1 nature:idNature moyenne:[lm.text doubleValue]];
			else {
				[game setValue:d part1:[part1.text doubleValue]  part2:[part2.text doubleValue] part3:[part3.text doubleValue]  part4:[part4.text doubleValue]  officiel:0 nature:idNature moyenne:[lm.text doubleValue]];
			}*/

			game.description =  description.text;
			NSLog(@"Game des = %s", description.text);
			[appDelegate addGame:self.game];
			[self.navigationController popViewControllerAnimated:YES];
		}
	}
	NSLog(@"Mivoaka sauvegarde");	
	
}
- (IBAction)tabButton:(id)sender {
	if(part1.editing){
		[part1 resignFirstResponder];
		[part2 becomeFirstResponder];
	}else if(part2.editing){
		[part2 resignFirstResponder];
		[part3 becomeFirstResponder];
	}else if(part3.editing){
		[part3 resignFirstResponder];
		if(part4.hidden==TRUE)
			[part1 becomeFirstResponder];
		else
			[part4 becomeFirstResponder];
	}else if(part4.editing){
		[part4 resignFirstResponder];
		[part1 becomeFirstResponder];
	}
	
}
- (IBAction)hidePave{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[part1 resignFirstResponder];
	[part2 resignFirstResponder];
	[part3 resignFirstResponder];
	[part4 resignFirstResponder];
	[description resignFirstResponder];
	NSDateFormatter *format = [[NSDateFormatter alloc] init];
	if (appDelegate.langue==0){//FR
		[format setDateFormat:@"EEEE d-MM-YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
		
	}else{//EN
		[format setDateFormat:@"EEE. MMM d, YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
		
	}
	[set setTitle:[[format stringFromDate:date.date] capitalizedString] forState:UIControlStateNormal];
	[set setTitle:[[format stringFromDate:date.date] capitalizedString] forState:UIControlStateSelected];
	[set setTitle:[[format stringFromDate:date.date] capitalizedString] forState:UIControlStateSelected];
	
	[format release];
}

- (IBAction)showPart{
	l4.hidden=FALSE;
	lp.hidden=FALSE;
	part4.hidden=FALSE;
	add.hidden=TRUE;
	//showTab=FALSE;
	[part4 becomeFirstResponder];
}
- (IBAction)showDate{
	[part1 endEditing:TRUE];
	[part2 endEditing:TRUE];
	[part3 endEditing:TRUE];
	[part4 endEditing:TRUE];
	[description endEditing:TRUE];
	date.hidden=!date.hidden;
}
- (IBAction)onFocus{
	description.tag=0;
	office.tag=0;
	date.hidden=TRUE;
	showTab=TRUE;
	doneButton.hidden=FALSE;
}
- (IBAction)onLostFocus{
	description.tag =0;
	office.tag=0;
	date.hidden=TRUE;
	showTab=FALSE;
	doneButton.hidden=TRUE;
}

- (IBAction)onEdit{
	BOOL fine;
	fine=YES;
	if([part1.text intValue]>300){
		fine=NO;
		[part1 setText:@""];
	}
	if([part2.text intValue]>300){
		fine=NO;
		[part2 setText:@""];
	}
	if([part3.text intValue]>300){
		fine=NO;
		[part3 setText:@""];
	}
	if([part4.text intValue]>300){
		fine=NO;
		[part4 setText:@""];
	}
	
	if (!fine){
		UIAlertView *alert;
		AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
		if (appDelegate.langue==0)
			alert=[[UIAlertView alloc] initWithTitle:@"Erreur iBowlling" message:@"Erreur de saisie\n\nLe score doit inférieur ou égale à 300" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
		else
			alert=[[UIAlertView alloc] initWithTitle:@"Error iBowlling" message:@"Input error\n\nMaximum value must under 300" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	n=0;
	total=0;
	if([part1.text intValue]>0){
		n++;
		total=total+[part1.text intValue];
	}
	if([part2.text intValue]>0){
		n++;
		total=total+[part2.text intValue];
	}

	if([part3.text intValue]>0){
		n++;
		total=total+[part3.text intValue];
	}
	if([part4.text intValue]>0){
		n++;
		total=total+[part4.text intValue];
	}
	
	if(n!=0){
		moyenne=total/n;
		lm.text=[NSString stringWithFormat:@"%0.2f",moyenne];
		//NSLog(@"N = %d et TOTAL =%d et MOYENNE =%0.2f",n,total,moyenne);
	}
}
#pragma mark Properties
/*Manipulation des membres du classes*/
- (int) idNature{
	return idNature;
}
- (void) setNature:(int)nature{
	idNature = nature;
}

-(BOOL)isOfficial{
	return isOfficial;
}
- (void) setOfficial: (BOOL)is{
	isOfficial=is;
}
- (BOOL) showTab{
	return showTab;
}
- (void) setshowTab : (BOOL) ok{
	showTab =ok;
}

@end
