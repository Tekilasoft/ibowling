//
//  Game.m
//  iBowl0
//
//  Created by Herison Andriamihaja on 02.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Game.h"

static sqlite3_stmt *insert_statement = nil;
static sqlite3_stmt *dehydrate_statement = nil;

@implementation Game
@synthesize description;
//CREATE TABLE game ('id' INTEGER PRIMARY KEY AUTOINCREMENT, 'day' REAL, 'p1' REAL, 'p2' REAL,'p3' REAL,'p4' REAL,'isOfficial' CHAR(2),'idNature' INTEGER, 'moyenne' REAL);
//INSERT INTO game(day, p1, p2,p3,p4,isOfficiel,idNature,moyenne) VALUES (1166832000, 200,200,200,0,'1',0,200);
//@synthesize i,day;
- (id)initValue:(NSInteger)pk day:(double)d part1:(double)par1  part2:(double)par2  part3:(double)par3  part4:(double)par4  officiel:(BOOL) off nature:(int)nat moyenne:(double)m{
	jour=d;
	p1=par1;
	p2=par2;
	p3=par3;
	p4=par4;
	i=pk;
	isOfficial=off;
	idNature=nat;
	moyenne=m;
	//NSLog([NSString stringWithFormat:@"jour = %0.2f, p1=%0.0f, isOfficial=%i, idNature=%i",jour,p1,isOfficial,idNature]);
	return self;
}

- (void)setValue:(double)d part1:(double)par1  part2:(double)par2  part3:(double)par3  part4:(double)par4 officiel:(BOOL) off nature:(int)nat moyenne:(double)m{
	jour=d;
	p1=par1;
	p2=par2;
	p3=par3;
	p4=par4;
	isOfficial=off;
	idNature=nat;
	moyenne=m;
	//	i=pk;
}
- (BOOL)insertIntoDatabase:(sqlite3 *)db {
	//	database=db;
	BOOL ok=FALSE;
	NSLog(@"MBOLA OK hatreto and id jeux =%d",i);
	NSLog(@"%i", isOfficial);
	NSLog(@"idNature = %d", idNature);
	NSLog(@"description = %s", [description UTF8String]);
	static char *sql = "INSERT INTO game(day,p1,p2,p3,p4,isOfficial,idNature,moyenne,description) VALUES(?,?,?,?,?,?,?,?,?)";
	//static char *sql = "INSERT INTO game(day,p1,p2,p3,p4,isOfficial,idNature,moyenne) VALUES(?,?,?,?,?,?,?,?)";
	if(i!=0){
		sql = "UPDATE game set day=?,p1=?,p2=?,p3=?,p4=?,isOfficial=?,idNature=?,moyenne=?,description=? WHERE id=?";
		NSLog(@"UPDATE game set day=%f,p1=%f,p2=%f,p3=%f,p4=%f, description=%s WHERE id=%d",jour,p1,p2,p3,p4,[description UTF8String], i);
		ok=TRUE;
		//if (dehydrate_statement == nil) {
			if (sqlite3_prepare_v2(db, sql, -1, &dehydrate_statement, NULL) != SQLITE_OK) {
                NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(db));
            }
		//}
		sqlite3_bind_double(dehydrate_statement, 1, jour);
		sqlite3_bind_double(dehydrate_statement, 2, p1);
		sqlite3_bind_double(dehydrate_statement, 3, p2);
		sqlite3_bind_double(dehydrate_statement, 4, p3);
		sqlite3_bind_double(dehydrate_statement, 5, p4);
		sqlite3_bind_text(dehydrate_statement, 6, [[NSString stringWithFormat:@"%i", isOfficial] UTF8String], -1, SQLITE_TRANSIENT);
		sqlite3_bind_int(dehydrate_statement, 7, idNature);
		sqlite3_bind_double(dehydrate_statement, 8, moyenne);
		sqlite3_bind_text(dehydrate_statement, 9, [description UTF8String], -1, SQLITE_TRANSIENT);
		sqlite3_bind_int(dehydrate_statement, 10, i);
		if (sqlite3_step(dehydrate_statement) != SQLITE_ERROR) {
			NSLog(@"MISE à JOUR FINE avec succès");
			//description = [[NSString alloc] initWithUTF8String:(char *) sqlite3_column_text(dehydrate_statement, 9)];
		}else{
			NSLog(@"MAJ IMPOSSIBLE");
			
		}
		ok=TRUE;//pour éviter l'ajout de la nouvelle ligne
		sqlite3_reset(dehydrate_statement);
		NSLog(@"dESCR == %s", [description UTF8String]);
	}else{
		NSLog(@"INSERT INTO game(day,p1,p2,p3,p4,isOfficial,idNature,moyenne, description) VALUES(%f,%f,%f,%f,%f,%d,%d,%f,'%s')",jour,p1,p2,p3,p4,isOfficial,idNature,moyenne, [description UTF8String]);
		sql = "INSERT INTO game(day,p1,p2,p3,p4,isOfficial,idNature,moyenne,description) VALUES(?,?,?,?,?,?,?,?,?)";
		//if (insert_statement == nil) {
			if (sqlite3_prepare_v2(db, sql, -1, &insert_statement, NULL) != SQLITE_OK) {
				NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(db));
			}
		//}
		sqlite3_bind_double(insert_statement, 1, jour);
		sqlite3_bind_double(insert_statement, 2, p1);
		sqlite3_bind_double(insert_statement, 3, p2);
		sqlite3_bind_double(insert_statement, 4, p3);
		sqlite3_bind_double(insert_statement, 5, p4);
		sqlite3_bind_text(insert_statement, 6, [[NSString stringWithFormat:@"%i", isOfficial] UTF8String], -1, SQLITE_TRANSIENT);
		sqlite3_bind_int(insert_statement, 7, idNature);
		sqlite3_bind_double(insert_statement, 8, moyenne);
		sqlite3_bind_text(insert_statement, 9, [description UTF8String], -1, SQLITE_TRANSIENT);
		int success= sqlite3_step(insert_statement);
		sqlite3_reset(insert_statement);
		if (success != SQLITE_ERROR) {
			NSLog(@"Insertion avec succès");
			i = sqlite3_last_insert_rowid(db);
		}else{
			NSLog(@"Insertion IMPOSSIBLE");
			ok=TRUE;//pour éviter l'ajout de la nouvelle ligne
		}
	}
	
  	return ok;
}
- (void)deleteFromDatabase:(sqlite3 *)db{
	// Compile the delete statement if needed.
	sqlite3_stmt *statement;
	const char *sql = "DELETE FROM game WHERE id=?";
	if (sqlite3_prepare_v2(db, sql, -1, &statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(db));
	}
	// Bind the primary key variable.
	sqlite3_bind_int(statement, 1, i);
	// Execute the query.
	int success = sqlite3_step(statement);
	// Reset the statement for future use.
	sqlite3_finalize(statement);
	// Handle errors.
	if (success != SQLITE_DONE) {
		NSAssert1(0, @"Error: failed to delete from database with message '%s'.", sqlite3_errmsg(db));
	}
}
#pragma mark Properties
// Accessors implemented below. All the "get" accessors simply return the value directly, with no additional
// logic or steps for synchronization. The "set" accessors attempt to verify that the new value is definitely
// different from the old value, to minimize the amount of work done. Any "set" which actually results in changing
// data will mark the object as "dirty" - i.e., possessing data that has not been written to the database.
// All the "set" accessors copy data, rather than retain it. This is common for value objects - strings, numbers, 
// dates, data buffers, etc. This ensures that subsequent changes to either the original or the copy don't violate 
// the encapsulation of the owning object.
//Getters methods
- (NSInteger)i {
    return i;
}
- (double)p1 {
    return p1;
}
- (double)p2 {
    return p2;
}
- (double)p3 {
    return p3;
}
- (double)p4 {
    return p4;
}
- (double) jour{
	return jour;
}
- (BOOL)isOfficial;{
	return isOfficial;
}
- (int)idNature{
	return idNature;
}
- (double) moyenne{
	return moyenne;
}
- (void)setP1:(double)p {
    p1= p;
}
- (void)setP2:(double)p {
    p2= p;
}
- (void)setP3:(double)p {
    p3= p;
}
- (void)setP4:(double)p {
    p4= p;
}
- (void)setJour:(double)j{
	jour=j;
}
- (void)setOfficial:(BOOL)is{
	isOfficial=is;
}
- (void)setIdNature:(int)p{
	idNature=p;
}
- (void)setMoyenne:(double)j{
	moyenne=j;
}
@end
