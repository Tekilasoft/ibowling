#import "ViewData.h"
#import "EditViewControler.h"
#import "Game.h"
#import "AppDelegate.h"

@implementation ViewData
@synthesize edit,game, addNavigationController, lab4, part1,part2, part3,t1,t2,t3,t4,lbs,sum,desc;
@synthesize	part4, titre, total, date, prev,first,next,last,switchView,segment, bar;

- (void)viewDidLoad {
    
	/*
	  self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRedo 
																						   target:self action:@selector(cancel:)] autorelease];
	  self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit 
	  target:self action:@selector(edit:)] autorelease];
	*/
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonSystemItemRedo 
																						   target:self action:@selector(cancel:)] autorelease];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonSystemItemEdit 
																							target:self action:@selector(editer:)] autorelease];
}

- (void)showGame:(Game *)g{
	NSLog(@"Aperçu du jeux");
	[switchView setOn:g.isOfficial animated:YES];
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	if (appDelegate.langue==0){//FR - french
		t1.text=@"1ère partie";
		t2.text=@"2ème partie";
		t3.text=@"3ème partie";
		t4.text=@"4ème partie";
		lbs.text=@"Total";
		[self.navigationItem.leftBarButtonItem setTitle:@"Retour"];
		[self.navigationItem.rightBarButtonItem setTitle:@"Editer"];
		if (g.isOfficial==TRUE){
			switch (idNature) {
				case 1:
					lab4.text=@"Championnat";
					break;
				case 2:
					lab4.text=@"Ligue Officiel";
					break;
				case 3:
					lab4.text=@"Tournoi Officiel";
					break;
				case 4:
					lab4.text=@"Entrainement";
					break;
				default:
					break;
			}
			//self.title = @"Parties officielles";
			[segment setTitle:@"Aller à Open"];
		}else{
			switch (idNature) {
				case 1:
					lab4.text=@"Championnat";
					break;
				case 2:
					lab4.text=@"Ligue Open";
					break;
				case 3:
					lab4.text=@"Tournoi Open";
					break;
				case 4:
					lab4.text=@"Practice";
					break;
				default:
					break;
			}
		}
		self.title=@"Consultation";
		if (!g.isOfficial){
			[segment setTitle:@"Aller à officielle"];
		}else{
			[segment setTitle:@"Aller à Open"];
		}
	}else{
		
		[self.navigationItem.leftBarButtonItem setTitle:@"Back"];
		[self.navigationItem.rightBarButtonItem setTitle:@"Edit"];
		if (g.isOfficial==TRUE){
			switch (idNature) {
				case 1:
					lab4.text=@"Championship";
					break;
				case 2:
					lab4.text=@"Licensed League";
					break;
				case 3:
					lab4.text=@"Licensed Tournament";
					break;
				case 4:
					lab4.text=@"Training";
					break;
				default:
					break;
			}
			[segment setTitle:@"Go to Open"];
		}else{
			switch (idNature) {
				case 1:
					lab4.text=@"Championship";
					break;
				case 2:
					lab4.text=@"Open League";
					break;
				case 3:
					lab4.text=@"Open Tournament";
					break;
				case 4:
					lab4.text=@"Training";
					break;
				default:
					break;
			}
		}
		
		
		//[self.navigationItem.rightBarButtonItem setTitle:@"Edit"];
		t1.text=@"1st game";
		t2.text=@"2nd game";
		t3.text=@"3rd game";
		t4.text=@"4th game";
		lbs.text=@"Pins";
		self.title=@"Preview";
		if (!g.isOfficial){
			[segment setTitle:@"Go to licensed"];
		}else{
			[segment setTitle:@"Go to Open"];
		}
		
	}
	if(g.description!=nil){
		desc.text=g.description;
		game=g;
	}
	int x=0;	
	if(g.p4<=0){
		t4.hidden=TRUE;
		part4.text=@"";
		//part4.hidden=TRUE;
	}else{
		t4.hidden=FALSE;
		part4.hidden=FALSE;
		part4.text=[NSString stringWithFormat: @"%d",(int) g.p4];
		x=(int) g.p4;
	}
	
	[total setTitle:[NSString stringWithFormat:@"%0.2f",g.moyenne]  forSegmentAtIndex:1];
	if (appDelegate.langue==0){//FR - french
		[total setTitle:@"Moyenne"  forSegmentAtIndex:0];
		if(g.isOfficial){
			[titre setTitle:@"Série officielle"  forSegmentAtIndex:0];
		}else
			[titre setTitle:@"Série Open"  forSegmentAtIndex:0];
	}else{
		[total setTitle:@"Average"  forSegmentAtIndex:0];
		if(g.isOfficial){
			[titre setTitle:@"Licensed serie"  forSegmentAtIndex:0];
		}else
			[titre setTitle:@"Open serie"  forSegmentAtIndex:0];
	}
	
	
	part1.text=[NSString stringWithFormat: @"%d",(int) g.p1];
	part2.text=[NSString stringWithFormat: @"%d",(int) g.p2];
	part3.text=[NSString stringWithFormat: @"%d",(int) g.p3];
	x=x+(int) g.p1+(int) g.p2+(int) g.p3;
	sum.text=[NSString stringWithFormat: @"%d",x];
	NSDateFormatter *format = [[NSDateFormatter alloc] init];
	if (appDelegate.langue==0){//FR
		[format setDateFormat:@"EEEE d-MM-YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
	}else{//EN
		[format setDateFormat:@"EEE. MMM, d YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
	}
	[date setTitle:[[format stringFromDate:[NSDate dateWithTimeIntervalSince1970:g.jour]] capitalizedString] forSegmentAtIndex:1];
	if(idNature == 1 || idNature==4)
		[segment setTitle:@""];
		//segment.visible=FALSE;
	[format release];	
}
- (void)viewWillAppear:(BOOL)animated {	
	first.hidden	= FALSE;
	prev.hidden		= FALSE;
	next.hidden		= FALSE;
	last.hidden		= FALSE;
	desc.text=@"";
	self.navigationItem.leftBarButtonItem.title=@"Back";
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	//[appDelegate selectGames:game.isOfficial ];
	[appDelegate getGames:game.isOfficial nature:game.idNature];
	position=0;
	while (position<=appDelegate.games.count) {
		Game *g=(Game *)[appDelegate.games objectAtIndex:position];
		if(game.i==g.i){
			game=g;
			break;
		}else
			position++;
	}
	if(position<=0){
		prev.hidden=TRUE;
		first.hidden=TRUE;
	}
	if(position>=appDelegate.games.count-1){
		next.hidden=TRUE;
		last.hidden=TRUE;
	}
	//bar.hidden=FALSE;
	[segment setEnabled:TRUE];
	segment.style =5;
	if (idNature==1 || idNature==4)
		[segment setEnabled:FALSE];
		//bar.hidden=TRUE;
	[self showGame:game];
	//NSLog(@"Affichage de valeur %s", self.navigationItem.leftBarButtonItem.title);
}
- (IBAction)cancel:(id)sender {
	[self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)goFirst:(id)sender{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	if(appDelegate.games.count>0){
		position=0;
		game=(Game *)[appDelegate.games objectAtIndex:position];
		[self showGame:game];
		prev.hidden=TRUE;
		first.hidden=TRUE;
		if(appDelegate.games.count>1){
			next.hidden=FALSE;
			last.hidden=FALSE;
		}
	}
}
- (IBAction)goPreview:(id)sender{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	if(position>0  && appDelegate.games.count>0){
		position--;
		game=(Game *)[appDelegate.games objectAtIndex:position];
		[self showGame:game];
		next.hidden=FALSE;
		last.hidden=FALSE;
		if(position<=0){
			prev.hidden=TRUE;
			first.hidden=TRUE;
		}
	}
}

- (IBAction)goLast:(id)sender{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	if(appDelegate.games.count>0){
		position=appDelegate.games.count-1;
		game=(Game *)[appDelegate.games objectAtIndex:position];
		[self showGame:game];
		next.hidden=TRUE;
		last.hidden=TRUE;
		if(position>0){
			prev.hidden = FALSE;
			first.hidden= FALSE;
		}
	}
}
- (IBAction)goNext:(id)sender{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	if((position+1)<appDelegate.games.count){
		position++;
		game=(Game *)[appDelegate.games objectAtIndex:position];
		[self showGame:game];
		prev.hidden		= FALSE;
		first.hidden	= FALSE;
		if(position>=appDelegate.games.count-1){
			next.hidden=TRUE;
			last.hidden=TRUE;
		}
	}
}
- (IBAction)editer:(id)sender{
	EditViewControler *controller = self.edit;
	NSLog(@"Verif game");
	controller.game=game;
	
	[controller setNature:idNature];
    if (addNavigationController == nil) {
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
        self.addNavigationController = navController;
        [navController release];
    }
	
	[self.navigationController pushViewController:controller animated:YES];
    [controller setEditing:NO animated:NO];
}
- (IBAction)basculer:(id)sender{
	
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	//[appDelegate selectGames:(!game.isOfficial)];
	[appDelegate getGames:(!game.isOfficial) nature: idNature];
	double jour= game.jour;
	//NSLog(@"Basculement : %i, avec game=%i",switchView.on, appDelegate.games.count);
	if (appDelegate.games.count>0){
		
		int i=-1;
		BOOL ok=FALSE;
		while(!ok){
			i++;
			if(i>=appDelegate.games.count)
				ok=TRUE;
			else{
				game=(Game *)[appDelegate.games objectAtIndex:i];
				position=i;
				if (game.jour<jour)
					ok=TRUE;
			}
		}
		if(game!=NULL){
			first.hidden	= FALSE;
			prev.hidden		= FALSE;
			next.hidden		= FALSE;
			last.hidden		= FALSE;
			if(position<=0){
				prev.hidden=TRUE;
				first.hidden=TRUE;
			}
			if(position>=appDelegate.games.count-1){
				next.hidden=TRUE;
				last.hidden=TRUE;
			}
			[self showGame:game];
		}

	}else{
		AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
		UIAlertView *alert;
		if (appDelegate.langue==0)//FR language
			alert=[[UIAlertView alloc] initWithTitle:@"iBowlling" message:@"Basculement annulé\nAucune partie trouvée" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
		else
			alert=[[UIAlertView alloc] initWithTitle:@"iBowlling" message:@"Swicth canceled\nNo game found" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
		[alert show];
		[alert release];
		[switchView setOn:(!switchView.on) animated:YES];
		[appDelegate selectGames:(!switchView.on)];
	}
	//[office setOn:isOfficial animated:YES];
}
- (EditViewControler *)edit {
    // Instantiate the add view controller if necessary.
    if (edit == nil) {
        edit = [[EditViewControler alloc] initWithNibName:@"Edit" bundle:nil];
    }
    return edit;
}
- (void)dealloc {
    // Release allocated resources.
    [lab4 release];
	[part4 release];
	[part3 release];
	[part2 release];
	[part1 release];
	[titre release];
	[total release];
	[date release];
	[prev release];
	[first release];
	[next release];
	[last release];
	[lbs release];
	[sum release];
    [desc release];
	[bar release];
	[addNavigationController release];
    [super dealloc];
}


- (int) idNature {
	return idNature;
}
- (void) setNature : (int) nature{
	idNature=nature;
}
- (int)position{
	return position;
}
- (void)setPosition:(int)p{
	position=p;
}
@end
