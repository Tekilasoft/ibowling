#import "MoreController.h"

@implementation MoreController
- (void)viewWillAppear:(BOOL)animated {
	/*UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"About iBowlling" message:@"iBowlling v1.0\nCopyright Août 2009 \nTekilasoft\nWeb : www.tekilasoft.com\n\nVotre moyenne générale :" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
	[alert show];
	[alert release];
	 */
}
@end
