#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@class EditViewControler,Game;
@interface ViewData : UIViewController /* Specify a superclass (eg: NSObject or NSView) */ {
	EditViewControler *edit;
	IBOutlet UILabel *lab4;
	IBOutlet UITextField *part1, *part2,*part3,*part4,*sum;
	IBOutlet  UILabel *t1,*t2,*t3,*t4,*lbs, *desc;
	IBOutlet UISegmentedControl *titre,*date, *total;
	IBOutlet UIButton *prev,*first, *next,*last;
	IBOutlet UIBarButtonItem *segment;
	UINavigationController *addNavigationController;
	IBOutlet UISwitch *switchView;
	IBOutlet UIToolbar *bar;
//	IBOutlet UISegmentedControl *segment;
	Game *game;
	int position, idNature;//Position courant de la partie daans le tableau des games
}
@property (nonatomic, retain) EditViewControler *edit;
@property (nonatomic, retain) Game *game;
@property (nonatomic, retain) UINavigationController *addNavigationController;
@property (nonatomic, retain) UILabel *lab4;
@property (nonatomic, retain) UITextField *part1, *part2,*part3,*part4,*sum;
@property (nonatomic, retain) UILabel *t1,*t2,*t3,*t4,*lbs,*desc;
@property (nonatomic, retain) UISegmentedControl *titre,*date, *total;
@property (nonatomic, retain) UIButton *prev,*first, *next,*last;
@property (nonatomic, retain) UISwitch *switchView;
@property (nonatomic, retain) UIBarButtonItem *segment;
@property (nonatomic, retain) UIToolbar *bar;

- (IBAction) cancel:(id)sender;
- (IBAction) editer:(id)sender;
- (IBAction) goFirst:(id)sender;
- (IBAction) goPreview:(id)sender;
- (IBAction) goLast:(id)sender;
- (IBAction) goNext:(id)sender;
- (IBAction) basculer:(id)sender;


- (int)position;
- (void)setPosition:(int)p;
- (int) idNature;
- (void) setNature : (int) nature;
@end
