//
//  Game.h
//  iBowl0
//
//  Created by Herison Andriamihaja on 02.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

//CREATE TABLE game ('id' INTEGER PRIMARY KEY AUTOINCREMENT, 'day' REAL, 'p1' REAL, 'p2' REAL,'p3' REAL,'p4' REAL,'isOfficial' CHAR(2),'idNature' INTEGER, 'moyenne' REAL);



@interface Game : NSObject {
	NSInteger i;
	double p1,p2,p3,p4,jour,moyenne;
	BOOL isOfficial;
	int idNature;
	NSString *description;
}

@property (assign, nonatomic, readonly) NSInteger i;
@property (assign, nonatomic) double p1,p2,p3,p4,jour;
@property (assign, nonatomic) NSString *description;


- (id)initValue:(NSInteger)pk day:(double)d part1:(double)p1  part2:(double)p2  part3:(double)p3  part4:(double)p4  officiel:(BOOL)off nature:(int)nat moyenne:(double)m;
- (void)setValue:(double)d part1:(double)par1  part2:(double)par2  part3:(double)par3  part4:(double)par4 officiel:(BOOL) off nature:(int)nat moyenne:(double)m;
- (BOOL)insertIntoDatabase:(sqlite3 *)db;
- (void)deleteFromDatabase:(sqlite3 *)db;

//Getter Methods
- (double)p1;
- (double)p2;
- (double)p3;
- (double)p4;
- (double)jour;
- (BOOL)isOfficial;
- (int)idNature;
- (double)moyenne;
//Setters Methods
- (void)setP1:(double)p;
- (void)setP2:(double)p;
- (void)setP3:(double)p;
- (void)setP4:(double)p;
- (void)setJour:(double)p;
- (void)setOfficial:(BOOL)is;
- (void)setIdNature:(int)p;
- (void)setMoyenne:(double)p;
@end
