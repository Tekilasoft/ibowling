//
//  iBowlTabAppDelegate.h
//  iBowlTab
//
//  Created by Herison Andriamihaja on 17.08.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@class Game;

@interface AppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate> {
    UIWindow *window;
    UITabBarController *tabBarController;
	UINavigationController *navigation;
	sqlite3 *database;
	NSMutableArray *games;
	int official_number,non_official_number;
	double total_official, total_non_official;
	int langue;
	NSString *teny;
}
@property (nonatomic, retain) NSMutableArray *games;
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;
@property (nonatomic, retain) IBOutlet UINavigationController *navigation;
@property (nonatomic, retain) NSString *teny;
- (void) addGame:(Game *)game;
- (void) removeGame:(Game *)game;
- (BOOL) selectGames:(BOOL)ok;
- (BOOL) getGames:(BOOL)ok nature:(int) n;
- (BOOL) selectFavory:(BOOL)ok nature:(int) n; //Les favory
- (BOOL) selectFavoryPart:(BOOL)ok nature:(int) n; // Les favory par Partie

- (int)official_number;
- (int)non_official_number;
- (double)total_official;
- (double)total_non_official;
- (int)langue;
/*- (char *)getLangue;
*/
- (void)setofficial_number:(int)n;
- (void)setnon_official_number:(int)n;
- (void)settotal_official:(double)n;
- (void)settotal_non_official:(double)n;
- (void)setLangue:(int) l;
- (BOOL)selectAll;

@end
