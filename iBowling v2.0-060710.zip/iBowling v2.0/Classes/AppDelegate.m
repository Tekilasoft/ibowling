//
//  iBowlTabAppDelegate.m
//  iBowlTab
//
//  Created by Herison Andriamihaja on 17.08.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//
//${PRODUCT_NAME} C'est la valeur de "Bundle display name" dans iBowlTab-Info.plist

//alter table game add column 'description' CHAR(50);


#import "AppDelegate.h"
#import "Game.h";

@interface AppDelegate (Private)
- (void)createEditableCopyOfDatabaseIfNeeded;
- (void)initializeDatabase;
@end

@implementation AppDelegate

@synthesize window;
@synthesize tabBarController,navigation,games,teny;


- (void)applicationDidFinishLaunching:(UIApplication *)application {
    [self createEditableCopyOfDatabaseIfNeeded];
    [self initializeDatabase];
	[self selectAll];
	 
	// Add the tab bar controller's current view as a subview of the window
    [window addSubview:tabBarController.view];
}


/*
// Optional UITabBarControllerDelegate method
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
}
*/

/*
// Optional UITabBarControllerDelegate method
- (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed {
}
*/


- (void)dealloc {
    [tabBarController release];
    [window release];
	[games release];
    [super dealloc];
}



- (void)createEditableCopyOfDatabaseIfNeeded {
    // First, test for existence.
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	NSLog(@"Chemin = %@", documentsDirectory);
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"ibowl.sqlite"];
    success = [fileManager fileExistsAtPath:writableDBPath];
    if (success) return;
    // The writable database does not exist, so copy the default to the appropriate location.
    NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"ibowl.sqlite"];
    success = [fileManager copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
    if (!success) {
        NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
    }
}

// Open the database connection and retrieve minimal information for all objects.
- (void)initializeDatabase {

	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"ibowl.sqlite"];
	langue=1;//EN - English
	
    if (sqlite3_open([path UTF8String], &database) == SQLITE_OK) {
		const char *sql = "SELECT langue, name FROM personne";
        sqlite3_stmt *statement;
		BOOL toUp=FALSE;
		if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
			while (sqlite3_step(statement) == SQLITE_ROW) {
                langue= sqlite3_column_int(statement,0);
				if (sqlite3_column_text(statement, 1)==nil){
					toUp=TRUE;
				}else {
					NSLog(@"Value de name =%s.",sqlite3_column_text(statement, 1));
				}

			}
        }
        sqlite3_finalize(statement);
		
		//if(toUp){
		
			sql = "alter table game add column 'description' CHAR(50)";
			if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) != SQLITE_OK) {
				NSLog(@"Table déjà à jours");
				//NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
			}else {
				int success= sqlite3_step(statement);
				sqlite3_reset(statement);
				if (success != SQLITE_ERROR) {				
					NSLog(@"Update ok");
				}else{
					NSLog(@"Uptade IMPOSSIBLE");
				}
				sqlite3_finalize(statement);
			}	
		//}
    } else {
        sqlite3_close(database);
    }
}

- (void)addGame:(Game *)game{
	if(database==nil){
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *path = [documentsDirectory stringByAppendingPathComponent:@"ibowl.sqlite"];
		sqlite3_open([path UTF8String], &database);
	}
	NSLog(@"Miiditra ato amin'ny AppDelegate");
	if(![game insertIntoDatabase:database]){ //  FAUX si INSERT
		[games addObject:game];
	}else{//MAJ Jeux
		
	}
}
- (void) removeGame:(Game *)game{
	[game deleteFromDatabase:database];
    [games removeObject:game];
}
- (BOOL)selectAll{
	BOOL fine=TRUE;
	non_official_number=0;
	official_number=0;
	total_official=0;
	total_non_official=0;

	if(database !=NULL){
		//const char *sql = "SELECT isOfficial,sum((p1%(p1-1))+(p2%(p2-1))+(p3%(p3-1))+(p4%(p4-1))), sum(p1+p2+p3+p4) FROM game group by isOfficial order by isOfficial";
		const char *sql = "SELECT isOfficial,sum((p1<>0)+(p2<>0)+(p3<>0)+(p4<>0)), sum(p1+p2+p3+p4) FROM game group by isOfficial order by isOfficial";
		sqlite3_stmt *statement;
		if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
			while (sqlite3_step(statement) == SQLITE_ROW) {
				//NSLog([NSString stringWithFormat:@"isOfficiel %s = %d",sqlite3_column_text(statement,0), sqlite3_column_int(statement,0)]);
				if (sqlite3_column_int(statement,0)==0){
					non_official_number=sqlite3_column_int(statement,1);
					total_non_official=sqlite3_column_double(statement, 2);
					//NSLog([NSString stringWithFormat:@"Opens : %d = %0.2f",non_official_number,total_non_official]);
				}else{
					official_number=sqlite3_column_int(statement,1);
					total_official=sqlite3_column_double(statement, 2);
					//NSLog([NSString stringWithFormat:@"Officielles : %d = %0.2f",official_number,total_official]);
				}
				//Game *game= [[Game alloc] initValue:primaryKey day:sqlite3_column_double(statement, 1) part1:sqlite3_column_double(statement, 2) part2:sqlite3_column_double(statement, 3) part3:sqlite3_column_double(statement, 4) part4:sqlite3_column_double(statement, 5)  officiel:ok nature:sqlite3_column_int(statement, 7) moyenne:sqlite3_column_double(statement, 8)];
			}
		}else
			fine=FALSE;
		sqlite3_finalize(statement);
	}else
		fine=FALSE;
	return fine;
}


- (BOOL) selectGames:(BOOL)ok{
	//NSMutableArray *gameArray = [[NSMutableArray alloc] init];
	games=[[NSMutableArray alloc] init];
	BOOL fine=TRUE;
	
	if(database !=NULL){
		const char *sql = "SELECT * FROM game WHERE isOfficial=? order by day DESC";
		sqlite3_stmt *statement;
		if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
			
			sqlite3_bind_text(statement, 1, [[NSString stringWithFormat:@"%i", ok] UTF8String], -1, SQLITE_TRANSIENT);
			int n=0;
			while (sqlite3_step(statement) == SQLITE_ROW) {
				int primaryKey = sqlite3_column_int(statement, 0);
				n++;
				//NSLog([NSString stringWithFormat: @"- Nombre de games = %i",n]);
				Game *game= [[Game alloc] initValue:primaryKey day:sqlite3_column_double(statement, 1) part1:sqlite3_column_double(statement, 2) part2:sqlite3_column_double(statement, 3) part3:sqlite3_column_double(statement, 4) part4:sqlite3_column_double(statement, 5)  officiel:ok nature:sqlite3_column_int(statement, 7) moyenne:sqlite3_column_double(statement, 8)];
				if (sqlite3_column_text(statement, 9)!=nil)
					game.description = [[NSString alloc] initWithUTF8String:(char *) sqlite3_column_text(statement, 9)];
				[games addObject:game];
				[game release];
			}
			//NSLog([NSString stringWithFormat: @"Nombre de games = %i",n]);
		}else
			fine=FALSE;
		sqlite3_finalize(statement);
	}else
		fine=FALSE;
	return fine;
}
- (BOOL) getGames:(BOOL)ok nature:(int) n{
	games=[[NSMutableArray alloc] init];
	BOOL fine=TRUE;
	if(database !=NULL){
		const char *sql = "SELECT * FROM game WHERE isOfficial=? and (idNature=? or idNature=0) order by day DESC";
		sqlite3_stmt *statement;
		if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
			
			sqlite3_bind_text(statement, 1, [[NSString stringWithFormat:@"%i", ok] UTF8String], -1, SQLITE_TRANSIENT);
			sqlite3_bind_int(statement, 2, n);
			int n=0;
			while (sqlite3_step(statement) == SQLITE_ROW) {
				int primaryKey = sqlite3_column_int(statement, 0);
				n++;
				Game *game= [[Game alloc] initValue:primaryKey day:sqlite3_column_double(statement, 1) part1:sqlite3_column_double(statement, 2) part2:sqlite3_column_double(statement, 3) part3:sqlite3_column_double(statement, 4) part4:sqlite3_column_double(statement, 5)  officiel:ok nature:sqlite3_column_int(statement, 7) moyenne:sqlite3_column_double(statement, 8)];
				if (sqlite3_column_text(statement, 9)!=nil){
					NSLog(@"Value = %s",sqlite3_column_text(statement, 9));
					game.description =[[NSString alloc ] initWithUTF8String:(char *) sqlite3_column_text(statement, 9)];
				}
				[games addObject:game];
				[game release];
			}
		}else
			fine=FALSE;
		sqlite3_finalize(statement);
	}else
		fine=FALSE;
	return fine;
	
}
- (BOOL) selectFavory:(BOOL)ok nature:(int) n{
	games=[[NSMutableArray alloc] init];
	BOOL fine=TRUE;
	if(database !=NULL){
		const char *sql = "SELECT * FROM game WHERE moyenne>=200 order by p1+p2+p3+p4 DESC, day DESC limit 0,5";
		if (n==1)
			sql = "SELECT * FROM game WHERE moyenne>=200 and idNature=1 order by p1+p2+p3+p4 DESC, day DESC limit 0,5";
		if (n==2)
			sql = "SELECT * FROM game WHERE moyenne>=200 and idNature=2 order by p1+p2+p3+p4 DESC, day DESC limit 0,5";
		if (n==3)
			sql = "SELECT * FROM game WHERE moyenne>=200 and idNature=3 order by p1+p2+p3+p4 DESC, day DESC limit 0,5";
		if (n==4)
			sql = "SELECT * FROM game WHERE moyenne>=200 and idNature=4 order by p1+p2+p3+p4 DESC, day DESC limit 0,5";
		sqlite3_stmt *statement;
		if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
			int n=0;
			while (sqlite3_step(statement) == SQLITE_ROW) {
				int primaryKey = sqlite3_column_int(statement, 0);
				n++;
				Game *game= [[Game alloc] initValue:primaryKey day:sqlite3_column_double(statement, 1) part1:sqlite3_column_double(statement, 2) part2:sqlite3_column_double(statement, 3) part3:sqlite3_column_double(statement, 4) part4:sqlite3_column_double(statement, 5)  officiel:sqlite3_column_int(statement, 6) nature:sqlite3_column_int(statement, 7) moyenne:sqlite3_column_double(statement, 8)];
				[games addObject:game];
				[game release];
			}
		}else
			fine=FALSE;
		sqlite3_finalize(statement);
	}else
		fine=FALSE;
	return fine;
}
- (BOOL) selectFavoryPart:(BOOL)ok nature:(int) n{
	//[games release];
	games=[[NSMutableArray alloc] init];
	BOOL fine=TRUE;
	if(database !=NULL){
		const char *sql = "SELECT id, day, p1,p2,p3,p4,isOfficial,idNature,moyenne,max(p1,p2,p3,p4) as max FROM game order by max DESC limit 0,5";
		if (n==1)
			sql = "SELECT id, day, p1,p2,p3,p4,isOfficial,idNature,moyenne,max(p1,p2,p3,p4) as max FROM game WHERE idNature=1 order by max DESC limit 0,5";
		if (n==2)
			sql = "SELECT id, day, p1,p2,p3,p4,isOfficial,idNature,moyenne,max(p1,p2,p3,p4) as max FROM game WHERE idNature=2 order by max DESC limit 0,5";
		if (n==3)
			sql = "SELECT id, day, p1,p2,p3,p4,isOfficial,idNature,moyenne,max(p1,p2,p3,p4) as max FROM game WHERE idNature=3 order by max DESC limit 0,5";
		if (n==4)
			sql = "SELECT id, day, p1,p2,p3,p4,isOfficial,idNature,moyenne,max(p1,p2,p3,p4) as max FROM game WHERE idNature=4 order by max DESC limit 0,5";
		sqlite3_stmt *statement;
		//Game *g=nil;
		
		if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
			int n=0;
			while (sqlite3_step(statement) == SQLITE_ROW) {
				
				int primaryKey = sqlite3_column_int(statement, 0);
				n++;
				NSLog(@"identity = %d", primaryKey);
				Game *game= [[Game alloc] initValue:primaryKey day:sqlite3_column_double(statement, 1) part1:sqlite3_column_double(statement, 2) part2:sqlite3_column_double(statement, 3) part3:sqlite3_column_double(statement, 4) part4:sqlite3_column_double(statement, 5)  officiel:sqlite3_column_int(statement,6) nature:sqlite3_column_int(statement, 7) moyenne:sqlite3_column_double(statement, 9)];
				/*if (g!=nil){
					
				}
				g=game;*/
				[games addObject:game];
				[game release];
			}
			NSLog(@"Nombre de données = %d", n);
		}else
			fine=FALSE;
		
		sqlite3_finalize(statement);
	}else
		fine=FALSE;
	return fine;
}

#pragma mark Properties
- (int)official_number{
	return official_number;
}
- (int)non_official_number{
	return non_official_number;
}
- (double)total_official{
	return total_official;
}
- (double)total_non_official{
	return total_non_official;
}
- (int)langue{
	//NSLog([NSString stringWithFormat:@"Get Langue =%s", langue]);
	return langue;
}
 
- (void)setLangue:(int) l{
	//NSLog([NSString stringWithFormat:@"Set Langue =%i", l]);
	langue=l;
	static char *sql ="UPDATE personne set langue=?";
	sqlite3_stmt *dehydrate_statement;
	if (sqlite3_prepare_v2(database, sql, -1, &dehydrate_statement, NULL) != SQLITE_OK) {
		//NSLog(@"ERROR : UPDATE personne set langue=%i",l);
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	sqlite3_bind_int(dehydrate_statement, 1, langue);
	sqlite3_step(dehydrate_statement);
	sqlite3_reset(dehydrate_statement);
}

- (void)setofficial_number:(int)n{
	official_number=n;
}
- (void)setnon_official_number:(int)n{
	non_official_number=n;
}
- (void)settotal_official:(double)n{
	total_official=n;
}
- (void)settotal_non_official:(double)n{
	total_non_official=n;
}
@end

