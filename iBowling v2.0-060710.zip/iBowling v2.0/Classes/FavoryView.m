//
//  FirstViewController.m
//  iBowlTab
//
//  Created by Herison Andriamihaja on 17.08.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "FavoryView.h"
#import "Game.h"
#import "AppDelegate.h"
#import "UITr.h"

@implementation FavoryView

@synthesize tableView, titre, segment, nature;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

- (void)viewWillAppear:(BOOL)animated {
	//NSLog(@"FAVORY= %i", favory);
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	if (favory)
		self.tableView.rowHeight = 35;
	else
		self.tableView.rowHeight = 55;
	if (appDelegate.langue==0){//FR
		if (favory){
			[appDelegate selectFavoryPart:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Meilleures parties" forSegmentAtIndex:1];
			[segment setTitle:@"Meilleures séries"];
		}else{
			[appDelegate selectFavory:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Meilleures séries" forSegmentAtIndex:1];
			[segment setTitle:@"Meilleures parties"];
		}
	}else{
		if (favory){
			[appDelegate selectFavoryPart:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Best games" forSegmentAtIndex:1];
			[segment setTitle:@"Best series"];
		}else{
			[appDelegate selectFavory:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Best series" forSegmentAtIndex:1];
			[segment setTitle:@"Best games"];
		}
	}
	tableView.allowsSelection=FALSE;
	[self.tableView reloadData];
	NSLog(@"Nombre de ligne =%d", appDelegate.games.count);
	/*}else{
		UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Info iBowlling" message:@"Vous n'avez pas de favory\n\nCopyright Août 2009 \nTekilasoft\nwww.tekilasoft.com" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}*/
}


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.tableView.rowHeight = 55; 
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (IBAction) switchFavory:(id) sender{
	favory=!favory;
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	if (favory)
		self.tableView.rowHeight = 35;
	else
		self.tableView.rowHeight = 55;
	if (appDelegate.langue==0){//FR
		if (favory){
			[appDelegate selectFavoryPart:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Meilleures parties" forSegmentAtIndex:1];
			[segment setTitle:@"Meilleures séries"];
		}else{
			[appDelegate selectFavory:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Meilleures séries" forSegmentAtIndex:1];
			[segment setTitle:@"Meilleures parties"];
		}
	}else{
		if (favory){
			[appDelegate selectFavoryPart:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Best games" forSegmentAtIndex:1];
			[segment setTitle:@"Best series"];
		}else{
			[appDelegate selectFavory:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Best series" forSegmentAtIndex:1];
			[segment setTitle:@"Best games"];
			
		}
	}
	//tableView.editing = FALSE;	
	//[self.tableView ];
	tableView.allowsSelection=FALSE;
	[self.tableView reloadData];
}
- (IBAction) switchNature:(int) nat{
	
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	if (favory)
		self.tableView.rowHeight = 35;
	else
		self.tableView.rowHeight = 55;
	
	if (appDelegate.langue==0){//FR
		if (favory){
			NSLog(@"VALUE = %i", [nature selectedSegmentIndex]);
			[appDelegate selectFavoryPart:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Meilleures parties" forSegmentAtIndex:1];
			[segment setTitle:@"Meilleures séries"];
		}else{
			
			[appDelegate selectFavory:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Meilleures séries" forSegmentAtIndex:1];
			[segment setTitle:@"Meilleures parties"];
		}
	}else{
		if (favory){
			NSLog(@"VALUE = %i", [nature selectedSegmentIndex]);
			[appDelegate selectFavoryPart:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Best games" forSegmentAtIndex:1];
			[segment setTitle:@"Best series"];
		}else{
			[appDelegate selectFavory:YES nature:[nature selectedSegmentIndex]];
			[titre setTitle:@"Best series" forSegmentAtIndex:1];
			[segment setTitle:@"Best games"];
		}
	}
	
	tableView.allowsSelection=FALSE;
	NSLog(@"Test de PB");	
	[self.tableView reloadData];
	NSLog(@"Pas de PB");
}
- (void)dealloc {
	[tableView release];
	[nature release];
	[titre release];
    [super dealloc];
}

#pragma mark Table Delegate and Data Source Methods
// These methods are all part of either the UITableViewDelegate or UITableViewDataSource protocols.

// This table will always only have one section. UNE Section contient UNE Ligne
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv {
    return 1;
}

// One row per book, the number of books is the number of rows.
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)section {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	NSLog(@"Nombre de data = %d", appDelegate.games.count);
    return appDelegate.games.count;
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//	NSLog(@"Nombre de lignes FAVORY =4");
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	Game *game= (Game *)[appDelegate.games objectAtIndex:indexPath.row];
	static NSString *CellIdentifier = @"CellIdent";
    UITr *cell = (UITr *) [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		UIViewController *c = [[UIViewController alloc] initWithNibName:@"TrTd" bundle:nil];
        cell = (UITr *)c.view;
		cell.accessoryType=UITableViewCellAccessoryNone;
		[c release];
    }
	cell.label.hidden=FALSE;
	cell.parts.hidden=FALSE;
	
	NSDateFormatter *format = [[NSDateFormatter alloc] init];
	//[format setDateFormat:@"EEEE d-MM-YYYY"];
	if (appDelegate.langue==0){//FR
		[format setDateFormat:@"EEEE d-MM-YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
		cell.label.text=@"Parties";
	}else{//EN
		[format setDateFormat:@"EEE. MMM d, YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
		cell.label.text=@"Games";
	}
	cell.title.text =[[format stringFromDate:[NSDate dateWithTimeIntervalSince1970:game.jour]] capitalizedString];
	
	
	NSLog(@"OFFICIEL ? %i", game.isOfficial);
	if(game.idNature==1){
		[cell.nat setTitle:@"C*" forState:UIControlStateNormal];
	}
	if(game.idNature==2){
		if (game.isOfficial==0)
			[cell.nat setTitle:@"L" forState:UIControlStateNormal];
		else
			[cell.nat setTitle:@"L*" forState:UIControlStateNormal];
	}
	if(game.idNature==3){
		if (game.isOfficial==0)
			[cell.nat setTitle:@"T" forState:UIControlStateNormal];
		else
			[cell.nat setTitle:@"T*" forState:UIControlStateNormal];
	}
	if(game.idNature==4){
		[cell.nat setTitle:@"P" forState:UIControlStateNormal];
	}
	cell.lic.hidden=TRUE;
	if (!favory){
		if(game.p4!=0){
			cell.parts.text =[NSString stringWithFormat: @"%d | %d | %d | %d",(int)game.p1,(int)game.p2,(int)game.p3,(int)game.p4];
		}else{
			cell.parts.text =[NSString stringWithFormat: @"%d | %d | %d",(int)game.p1,(int)game.p2,(int)game.p3];
		}
		cell.moyenne.text=[NSString stringWithFormat:@"%0.2f",game.p1+game.p2+game.p3+game.p4];
	}else{
		if (game.isOfficial)
			cell.parts.text=@"Officielle";//[NSString stringWithFormat:@"%0.2f",game.moyenne];
		else
			cell.parts.text=@"Open";
		cell.lic.hidden=TRUE;
		cell.label.hidden=TRUE;
		cell.parts.hidden=TRUE;
		cell.moyenne.text=[NSString stringWithFormat:@"%0.2f",game.moyenne];
	}
	
	[format release];
	return cell;
}

/*
- (NSIndexPath *)tableView:(UITableView *)tv willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	return nil;
}

- (void)tableView:(UITableView *)tv commitEditingStyle:(UITableViewCellEditingStyle)editingStyle 
forRowAtIndexPath:(NSIndexPath *)indexPath {
}
 */

@end
