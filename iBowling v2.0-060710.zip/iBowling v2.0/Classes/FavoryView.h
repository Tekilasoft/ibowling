//
//  FirstViewController.h
//  iBowlTab
//
//  Created by Herison Andriamihaja on 17.08.09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@class Game;

@interface FavoryView : UIViewController {
	IBOutlet UITableView *tableView;
	IBOutlet UISegmentedControl *titre, *nature;
	IBOutlet UIBarButtonItem *segment;
	BOOL favory;
}
@property (nonatomic, retain) UITableView *tableView;
@property(nonatomic,retain) UISegmentedControl *titre, *nature;
@property(nonatomic, retain) IBOutlet UIBarButtonItem *segment;

- (IBAction) switchFavory:(id) sender;
- (IBAction) switchNature:(int) nat;
@end
