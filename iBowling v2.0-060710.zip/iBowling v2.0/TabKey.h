#import <Foundation/Foundation.h>

@interface TabKeyButton : UIButton {
	
}

+ (TabKeyButton *) tabKeyButton;

@end


/**
 *	The class used to create the keypad
 */
@interface TabKey : NSObject {
	
	UITextField *currentTextField;
	
	TabKeyButton *tabKeytButton;
	
	NSTimer *showTabKeyTimer;
}

@property (nonatomic, retain) NSTimer *showTabKeyTimer;
@property (nonatomic, retain) TabKeyButton *tabKeyButton;

@property (assign) UITextField *currentTextField;

#pragma mark -
#pragma mark Show the keypad

+ (TabKey *) keypadForTextField:(UITextField *)textField; 

- (void) removeButtonFromKeyboard;

@end

//@end

