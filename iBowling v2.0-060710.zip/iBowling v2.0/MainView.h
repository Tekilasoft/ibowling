#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@class TableView, Game;

@interface MainView :UIViewController /* Specify a superclass (eg: NSObject or NSView) */ {
	TableView *tv;
	UINavigationController *addNavigationController;
	IBOutlet UITextField *nb_NO,*nb_O,*tot_NO,*tot_O,*moy_O,*moy_NO, *nb,*somme,*moyenne;
	IBOutlet UITextField *text1,*text2,*text3,*text4,*text5,*text6,*text7;
	IBOutlet UIButton *off,*on;
	IBOutlet UIButton *one, *two, *three,*four;
	IBOutlet UILabel *Lone, *Ltwo, *Lthree,*Lfour;
}
@property (nonatomic, retain) TableView *tv;
@property (nonatomic, retain) UINavigationController *addNavigationController;
@property (nonatomic, retain) UITextField *nb_NO,*nb_O,*tot_NO,*tot_O,*moy_O,*moy_NO, *nb,*somme,*moyenne;
@property (nonatomic, retain) UITextField *text1,*text2,*text3,*text4,*text5,*text6,*text7;
@property (nonatomic, retain) UIButton *off,*on;
@property (nonatomic, retain) IBOutlet UIButton *one, *two, *three,*four;
@property (nonatomic, retain) IBOutlet UILabel *Lone, *Ltwo, *Lthree,*Lfour;
- (IBAction)info;
- (IBAction)goOfficiel:(id)sender;
- (IBAction)goNoOfficiel:(id)sender;
- (IBAction)showInfo:(id) sender;
- (void) setTitle : (int) langue;
- (IBAction) setFR;
- (IBAction) setEN;
@end
