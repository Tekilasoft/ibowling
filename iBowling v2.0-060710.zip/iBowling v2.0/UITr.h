#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface UITr : UITableViewCell /* Specify a superclass (eg: NSObject or NSView) */ {
	IBOutlet UILabel *title, *moyenne,*parts, *label;
	IBOutlet UIButton *nat, *lic;
}
@property (nonatomic, retain) UILabel *title, *moyenne, *parts, *label;
@property (nonatomic, retain) UIButton *nat, *lic;
@end
