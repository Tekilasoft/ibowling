#import "MainView.h"
#import "TableView.h"
#import "Game.h"
#import "AppDelegate.h"

@implementation MainView
@synthesize tv,addNavigationController,nb_NO,nb_O,tot_NO,tot_O,moy_O,moy_NO,nb,somme,moyenne;
@synthesize text1, text2, text3, text4, text5, text6, text7, on,off;
@synthesize one, two, three, four; //For the 4 buttons
@synthesize Lone, Ltwo, Lthree, Lfour; //For the 4 labels of the boutons

/*
 Partie initialisation de l'application
 */
- (void)viewWillAppear:(BOOL)animated {

	nb_NO.text=@"0";
	nb_O.text=@"0";
	nb.text=@"0";
	tot_NO.text=@"0.00";
	tot_O.text=@"0.00";
	somme.text=@"0.00";
	moy_NO.text=@"0.00";
	moy_O.text=@"0.00";
	moyenne.text=@"0.00";
	
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	if ([appDelegate selectAll]){
		nb_NO.text=[NSString stringWithFormat:@"%d", appDelegate.non_official_number];
		nb_O.text=[NSString stringWithFormat:@"%d", appDelegate.official_number];
		nb.text=[NSString stringWithFormat:@"%d", appDelegate.official_number+appDelegate.non_official_number];
		tot_NO.text=[NSString stringWithFormat:@"%0.0f", appDelegate.total_non_official];
		tot_O.text=[NSString stringWithFormat:@"%0.0f", appDelegate.total_official];
		somme.text=[NSString stringWithFormat:@"%0.0f", appDelegate.total_official+appDelegate.total_non_official];

		if (appDelegate.non_official_number>0)
			moy_NO.text=[NSString stringWithFormat:@"%0.2f", appDelegate.total_non_official/appDelegate.non_official_number];
		if (appDelegate.official_number>0)
			moy_O.text=[NSString stringWithFormat:@"%0.2f", appDelegate.total_official/appDelegate.official_number];
		if (appDelegate.official_number+appDelegate.non_official_number>0)
			moyenne.text=[NSString stringWithFormat:@"%0.2f", (appDelegate.total_official+appDelegate.total_non_official)/(appDelegate.official_number+appDelegate.non_official_number)];
	}
	[self setTitle:appDelegate.langue];
	
}
- (TableView *)tv {
    // Instantiate the add view controller if necessary.
    if (tv == nil) {
        tv = [[TableView alloc] initWithNibName:@"TableView" bundle:nil];
    }
    return tv;
}

/*Fin de la partie d'initialisation*/


/*
 *****************************
 * Traitement des évenements *
 *****************************
 */

/*Début e la partie de gestion des événements boutons*/
- (IBAction)info{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	UIAlertView *alert;
	if (appDelegate.langue==0)//FR - Français
		alert=[[UIAlertView alloc] initWithTitle:@"A propos" message:@"iBowling v2.0\nCopyright 2010 \nTekilasoft\nwww.tekilasoft.com\n" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
	else
		alert=[[UIAlertView alloc] initWithTitle:@"About iBowling" message:@"iBowling v2.0\nCopyright 2010 \nTekilasoft\nwww.tekilasoft.com\n" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (IBAction)showInfo:(id) sender{
	NSLog(@"TAG sender = %d", [sender tag]);
	TableView *controller = self.tv;
	if([sender tag]!=4){
		[controller setOfficial:1];
	}else//Entrainements
		[controller setOfficial:0];
	
	[controller setNature:[sender tag]];
    if (addNavigationController == nil) {
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
        self.addNavigationController = navController;
        [navController release];
    }
	[self.navigationController pushViewController:controller animated:YES];
    [controller setEditing:NO animated:NO];
}


- (IBAction)goOfficiel:(id)sender{
	TableView *controller = self.tv;
	[controller setOfficial:TRUE];
    if (addNavigationController == nil) {
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
        self.addNavigationController = navController;
        [navController release];
    }
	[self.navigationController pushViewController:controller animated:YES];
    [controller setEditing:NO animated:NO];
}
- (IBAction)goNoOfficiel:(id)sender{
	TableView *controller = self.tv;
	[controller setOfficial:NO];
    if (addNavigationController == nil) {
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
        self.addNavigationController = navController;
        [navController release];
    }
	[self.navigationController pushViewController:controller animated:YES];
    [controller setEditing:NO animated:NO];
}

/*
 *********************************
 * END Traitement des évenements *
 *********************************
 */

- (void) setTitle : (int) langue{
	if (langue==0){//FR - Français
		Lone.text =@"Championnats";
		Ltwo.text =@"Ligues";
		Lthree.text =@"Tournois";
		Lfour.text =@"Entrainements";
		
		text1.text=@" Parties";
		text2.text=@"#";
		text3.text=@"Quilles";
		text4.text=@"Moyenne";
		text5.text=@" Officielle";
		text6.text=@" Open";
		text7.text=@" Parties";
	}else{//EN - English
		Lone.text =@"Championships";
		Ltwo.text =@"Leagues";
		Lthree.text =@"Tournaments";
		Lfour.text =@"Practices";
		
		text1.text=@" Games";
		text2.text=@"#";
		text3.text=@"Pins";
		text4.text=@"Average";
		text5.text=@" Licensed";
		text6.text=@" Open";
		text7.text=@" Games";
	}
}
- (IBAction) setFR{
	[self setTitle:0];
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[appDelegate setLangue:0];
};
- (IBAction) setEN{
	[self setTitle:1];
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[appDelegate setLangue:1];
}
- (void)viewDidLoad {
    [super viewDidLoad];
	one.tag		=1;
	two.tag		=2;
	three.tag	=3;
	four.tag	=4;
}
- (void)dealloc {
    // Release allocated resources.
    [tv release];
	[nb_NO release];
	[nb_O release];
	[tot_NO release];
	[tot_O release];
	[moy_O release];
	[moy_NO release];
	[nb release];
	[somme release];
	[moyenne release];
    [addNavigationController release];
	[text1 release];
	[text2 release];
	[text3 release];
	[text4 release];
	[text5 release];
	[text6 release];
	[text7 release];
	[on release];
	[off release];
    [super dealloc];
}
@end
