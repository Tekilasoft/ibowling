#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@class Game, EditViewControler,ViewData;
@interface TableView : UIViewController {
    IBOutlet UITableView *tableView;
	BOOL isOfficial;
	EditViewControler *edit; //Passage au controlleur de la prochaine fenêtre
	ViewData *viewData;
	BOOL view;
	UINavigationController *addNavigationController;
	int n,ns,idNature; //ns : nombre de series
	double moyenne,total,tg;
	IBOutlet UIBarButtonItem *segment;
	NSString *titre, *bouton;
	IBOutlet UIToolbar *toolBar;
}
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) EditViewControler *edit;
@property (nonatomic, retain) UINavigationController *addNavigationController;
@property (nonatomic, retain) ViewData *viewData;
@property (nonatomic, retain) UIBarButtonItem *segment;
@property (nonatomic, retain) UIToolbar *toolBar;
//- (IBAction)edit:(id)sender;
- (IBAction)add:(id)sender;
- (IBAction)basculer:(id)sender;

/*traitement de variable privée*/
- (BOOL) isOfficial;
- (void) setOfficial: (BOOL)is;
- (int) idNature;
- (void) setNature : (int) nature;
@end
