#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "TabKey.h"

@class Game;//Gestion des games pour ajout et modif;
@interface EditViewControler :UIViewController /* Specify a superclass (eg: NSObject or NSView) */ {
	IBOutlet UITextField *part1, *part2, *part3, *part4, *description;
	IBOutlet UIDatePicker *date;
	UIButton *doneButton;
	IBOutlet UIButton *add, *set;
	IBOutlet UISwitch *office;
	IBOutlet UILabel *lp, *lm, *lab1, *lab2,*lab3,*lab4,*labg, *labo, *l4;
	NSString *value;
	BOOL isOfficial, showTab; //Statut du jeux, statut du pavet TAB
	Game *game;
	NSString *tmp;
	int n, idNature;
	double moyenne,total;
}
@property (nonatomic, retain) UITextField *part1, *part2, *part3, *part4, *description;
@property (nonatomic, retain) UIDatePicker *date;
@property (nonatomic, retain) UIButton *add, *set, *doneButton;
@property (nonatomic, retain) UILabel *lp, *lm, *lab1, *lab2,*lab3,*lab4,*labg, *labo, *l4;
@property (nonatomic, retain) UISwitch *office;
@property (nonatomic, retain) Game *game;
@property (nonatomic, retain) NSString *value;

//- (IBAction) backgroundTap;

- (IBAction)cancel:(id)sender;
- (IBAction)save:(id)sender;
- (IBAction)textPave;
- (IBAction)hidePave;
- (IBAction)showPart;
- (IBAction)showDate;
- (IBAction)onFocus;
- (IBAction)onLostFocus;
- (IBAction)onEdit;
- (IBAction)tabButton:(id)sender;
- (int) idNature;
- (void) setNature:(int)nature;
- (BOOL) isOfficial;
- (void) setOfficial: (BOOL)is;
- (BOOL) showTab;
- (void) setshowTab : (BOOL) ok;
@end
