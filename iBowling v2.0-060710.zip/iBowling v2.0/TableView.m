#import "TableView.h"
#import "AppDelegate.h"
#import "Game.h"
#import "UITr.h"
#import "EditViewControler.h"
#import "ViewData.h"

@implementation TableView

@synthesize tableView,edit,addNavigationController,viewData,segment,toolBar;
- (void)viewDidLoad {
   
	/*self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit 
																						   target:self action:@selector(setEditing:)] autorelease];
    
	*/
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd 
																							target:self action:@selector(add:)] autorelease];
	self.navigationItem.leftBarButtonItem = self.editButtonItem;

	view=NO;
	self.tableView.rowHeight = 55; // 75 pixel square image + 10 pixels of padding on either side.	
}


- (void)viewWillAppear:(BOOL)animated {
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	if (appDelegate.langue==0){//FR - french
		self.navigationItem.leftBarButtonItem.title=@"Editer";
		if (isOfficial==TRUE){
			switch (idNature) {
				case 1:
					self.title=@"Championnat";
					break;
				case 2:
					self.title=@"Ligue Officiel";
					break;
				case 3:
					self.title=@"Tournoi Officiel";
					break;
				case 4:
					self.title=@"Entrainement";
					break;
				default:
					break;
			}
			//self.title = @"Parties officielles";
			[segment setTitle:@"Aller à Open"];
		}else{
			switch (idNature) {
				case 1:
					self.title=@"Championnat";
					break;
				case 2:
					self.title=@"Ligue non officiel";
					break;
				case 3:
					self.title=@"Tournoi non officiel";
					break;
				case 4:
					self.title=@"Entrainement";
					break;
				default:
					break;
			}
			//self.title = @"Parties Opens";
			[segment setTitle:@"Aller à Officielle"];
		}
	}else{//EN- English
		self.navigationItem.leftBarButtonItem.title=@"Edit";
		if (isOfficial==TRUE){
			switch (idNature) {
				case 1:
					self.title=@"Championship";
					break;
				case 2:
					self.title=@"Official League";
					break;
				case 3:
					self.title=@"Official Tournament";
					break;
				case 4:
					self.title=@"Training";
					break;
				default:
					break;
			}
			[segment setTitle:@"Go to Open"];
		}else{
			switch (idNature) {
				case 1:
					self.title=@"Championship";
					break;
				case 2:
					self.title=@"Open League";
					break;
				case 3:
					self.title=@"Open Tournament";
					break;
				case 4:
					self.title=@"Training";
					break;
				default:
					break;
			}
			//self.title = @"Un-licensed games";
			[segment setTitle:@"Go to Licensed"];
		}
	}

	toolBar.hidden=FALSE;
	if (idNature==1 || idNature==4){ // Championnat
		//On n'affiche pas le bouton de basculement
		toolBar.hidden=TRUE;
	}
	NSLog(@"Valeur de isOfficial = %d, et idNature = %i", isOfficial, idNature);
	[appDelegate getGames:isOfficial nature:idNature];	
	ns=0;
	tg=0;
	[self.tableView reloadData];
}

// Invoked when the user touches Edit.
- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
	view=editing;
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    // Updates the appearance of the Edit|Done button as necessary.
    [super setEditing:editing animated:animated];
    [self.tableView setEditing:editing animated:YES];
    // Disable the add button while editing.
    if (editing) {
        self.navigationItem.rightBarButtonItem.enabled = NO;
		if (appDelegate.langue==0)//FR - french
			self.navigationItem.leftBarButtonItem.title=@"Terminer";
		else {
			self.navigationItem.leftBarButtonItem.title=@"Done";
		}
    } else {
		self.navigationItem.rightBarButtonItem.enabled = YES;
		
		if (appDelegate.langue==0)//FR - french
			self.navigationItem.leftBarButtonItem.title=@"Editer";
		else {
			self.navigationItem.leftBarButtonItem.title=@"Edit";
		}

    }
}
 
- (void)dealloc {
    // Release allocated resources.
    [tableView release];
	[viewData release];
    [addNavigationController release];
    [super dealloc];
}

- (EditViewControler *)edit {
    // Instantiate the add view controller if necessary.
    if (edit == nil) {
        edit = [[EditViewControler alloc] initWithNibName:@"Edit" bundle:nil];
    }
    return edit;
}
- (ViewData *)viewData {
    // Instantiate the add view controller if necessary.
    if (viewData == nil) {
        viewData = [[ViewData alloc] initWithNibName:@"ViewData" bundle:nil];
    }
    return viewData;
}


/*Tous les evenements*/
/*- (IBAction)edit:(id)sender{
}*/
- (IBAction)add:(id)sender{
	EditViewControler *controller = self.edit;
	controller.game=nil;
	[controller setOfficial:isOfficial];
	[controller setNature:idNature];
    if (addNavigationController == nil) {
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
        self.addNavigationController = navController;
        [navController release];
    }
	[self.navigationController pushViewController:controller animated:YES];
    [controller setEditing:YES animated:NO];
}
- (IBAction)basculer:(id)sender{
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];	
	isOfficial=!isOfficial;
	
	if (appDelegate.langue==0){//FR - french
		if (isOfficial==TRUE){
			switch (idNature) {
				case 1:
					self.title=@"Championnat";
					break;
				case 2:
					self.title=@"Ligue Officiel";
					break;
				case 3:
					self.title=@"Tournoi Officiel";
					break;
				case 4:
					self.title=@"Entrainement";
					break;
				default:
					break;
			}
			//self.title = @"Parties officielles";
			[segment setTitle:@"Aller à Open"];
		}else{
			switch (idNature) {
				case 1:
					self.title=@"Championnat";
					break;
				case 2:
					self.title=@"Ligue Open";
					break;
				case 3:
					self.title=@"Tournoi Open";
					break;
				case 4:
					self.title=@"Entrainement";
					break;
				default:
					break;
			}
			//self.title = @"Parties Opens";
			[segment setTitle:@"Aller à Officielle"];
		}
	}else{//EN- English
		if (isOfficial==TRUE){
			switch (idNature) {
				case 1:
					self.title=@"Championship";
					break;
				case 2:
					self.title=@"Official League";
					break;
				case 3:
					self.title=@"Official Tournament";
					break;
				case 4:
					self.title=@"Practice";
					break;
				default:
					break;
			}
			[segment setTitle:@"Go to open"];
		}else{
			switch (idNature) {
				case 1:
					self.title=@"Championship";
					break;
				case 2:
					self.title=@"Open League";
					break;
				case 3:
					self.title=@"Open Tournament";
					break;
				case 4:
					self.title=@"Practice";
					break;
				default:
					break;
			}
			//self.title = @"Un-licensed games";
			[segment setTitle:@"Go to Licensed"];
		}
	}
	[appDelegate getGames:isOfficial nature:idNature];
	//[appDelegate selectGames:isOfficial];
	ns=0;
	tg=0;
	[self.tableView reloadData];
}

/*Manipulation des membres du classes*/
-(BOOL) isOfficial{
	return isOfficial;
}
- (void) setOfficial: (BOOL)is{
	isOfficial=is;
}
- (int) idNature {
	return idNature;
}
- (void) setNature : (int) nature{
	idNature=nature;
}

#pragma mark Table Delegate and Data Source Methods
// These methods are all part of either the UITableViewDelegate or UITableViewDataSource protocols.

// This table will always only have one section. UNE Section contient UNE Ligne
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv {
    return 1;
}

// One row per book, the number of books is the number of rows.
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)section {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	//NSLog(@"Nombre de ligne =%d", appDelegate.games.count);
    return appDelegate.games.count;
}
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	Game *game= (Game *)[appDelegate.games objectAtIndex:indexPath.row];
	static NSString *CellIdentifier = @"CellIdent";
    UITr *cell = (UITr *) [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		UIViewController *c = [[UIViewController alloc] initWithNibName:@"TrTd" bundle:nil];
        cell = (UITr *)c.view;
		[c release];
    }
	
	NSDateFormatter *format = [[NSDateFormatter alloc] init];
	cell.lic.hidden=TRUE;
	cell.nat.hidden=TRUE;
	if (appDelegate.langue==0){//FR
		[format setDateFormat:@"EEEE d-MM-YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"] autorelease]];
		cell.label.text=@"Parties";
		//cell.label.text=game.description;
	}else{//EN
		[format setDateFormat:@"EEE. MMM d, YYYY"];
		[format setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
		cell.label.text=@"Games";
		//cell.label.text=game.description;
	}
	cell.title.text =[[format stringFromDate:[NSDate dateWithTimeIntervalSince1970:game.jour]] capitalizedString];//[NSString stringWithFormat: @"%@",game.day];// @"Goop";
	n=0;
	total=0;
	if(game.p1>0){
		n++;
		total=total+game.p1;
	}
	if(game.p2>0){
		n++;
		total=total+game.p2;
	}
	if(game.p3>0){
		n++;
		total=total+game.p3;
	}
	if(game.p4>0){
		n++;
		total=total+game.p4;
	}
	if(n!=0){
		moyenne=total/n;
		cell.moyenne.text=[NSString stringWithFormat:@"%0.2f",moyenne];
		tg=tg+total;
		ns=ns+n;
	}
	
	if(game.p4!=0){
		cell.parts.text =[NSString stringWithFormat: @"%d | %d | %d | %d",(int)game.p1,(int)game.p2,(int)game.p3,(int)game.p4];
		//cell.moyenne.text=[NSString stringWithFormat: @"%0.2f",(game.p1+game.p2+game.p3+game.p4)/4];
	}else{
		cell.parts.text =[NSString stringWithFormat: @"%d | %d | %d",(int)game.p1,(int)game.p2,(int)game.p3];
		//cell.moyenne.text=[NSString stringWithFormat: @"%0.2f",(game.p1+game.p2+game.p3)/3];
	}
	
	[format release];
	return cell;
}


- (NSIndexPath *)tableView:(UITableView *)tv willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSLog(@"Affichage d'un jeu");
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    Game *game = [appDelegate.games objectAtIndex:indexPath.row];
	
	if(view==NO){ //Apercu de données
		ViewData *controller = self.viewData;
		controller.game =game;
		[controller setNature:idNature];
		[controller setPosition:indexPath.row];
		NSLog(@"Jeux ok");
		if (addNavigationController == nil) {
			UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
			self.addNavigationController = navController;
			[navController release];
		}
		[self.navigationController pushViewController:controller animated:YES];
		[controller setEditing:NO animated:NO];
		
	}else{
		NSLog(@"MBOLA OK hatreto and id jeux =%d",game.i);
		EditViewControler *controller = self.edit;
		controller.game=game;
		if (addNavigationController == nil) {
			UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
			self.addNavigationController = navController;
			[navController release];
		}
		[self.navigationController pushViewController:controller animated:YES];
		//[controller setEditing:NO animated:NO];
		[controller setEditing:YES animated:NO];
	}
	
	return nil;
}

- (void)tableView:(UITableView *)tv commitEditingStyle:(UITableViewCellEditingStyle)editingStyle 
forRowAtIndexPath:(NSIndexPath *)indexPath {
	
	AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	Game *game = [appDelegate.games objectAtIndex:indexPath.row];
	n=0;
	total=0;
	if(game.p1>0){
		n++;
		total=total+game.p1;
	}
	if(game.p2>0){
		n++;
		total=total+game.p2;
	}
	if(game.p3>0){
		n++;
		total=total+game.p3;
	}
	if(game.p4>0){
		n++;
		total=total+game.p4;
	}
	if(n!=0){
		tg=tg-total;
		ns=ns-n;
	}
	[appDelegate removeGame:game];
	[self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}


@end
