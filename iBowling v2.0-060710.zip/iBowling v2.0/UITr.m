#import "UITr.h"

@implementation UITr
@synthesize title,moyenne, parts, label, nat, lic;

/*- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
        // Initialization code
    }
    return self;
}
*/

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
	
    [super setSelected:selected animated:animated];

}



- (void)dealloc {
    [super dealloc];
}


@end
